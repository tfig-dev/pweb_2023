﻿namespace Ex1.Models
{
    public class TipoDeAula
    {
        public int Id { get; set; }
        public string Nome { get; set; }
        public float ValorHora { get; set; }
    }
}
