﻿using Ex1.Models;
using System.ComponentModel.DataAnnotations;

namespace Ex1.ViewModels
{
    public class PesquisaCursoViewModel
    {
        public List<Curso> ListaDeCursos { get; set; }
        public int NumResultados { get; set; }

        [Required]
        [Display(Name = "Texto", Prompt = "introduza o texto a pesquisar")]
        public string TextoAPesquisar { get; set; }
    }
}
