﻿using System.ComponentModel.DataAnnotations;

namespace Ex1.Models
{
    public class Categoria
    {
        public int Id { get; set; }

        [Display(Name = "Nome da categoria", Prompt = "Introduza o nome da categoria", Description = "Nome da categoria")]
        public string Nome { get; set; }

        [Display(Name = "Descrição", Prompt = "Introduza a descrição", Description = "Descrição da categoria")]
        public string Descricao { get; set; }
        public bool Disponivel { get; set; }
    }
}
