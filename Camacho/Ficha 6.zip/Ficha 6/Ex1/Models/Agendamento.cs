﻿namespace Ex1.Models
{
    public class Agendamento
    {
        public int Id { get; set; }
        //public string Cliente { get; set; } 
        public string ClienteId { get; set; }
        public ApplicationUser Cliente { get; set; }
        public DateTime DataInicio { get; set; }
        public DateTime DataFim { get; set; }
        public int DuracaoEmHoras { get; set; }
        public int DuracaoEmMinutos { get; set; }
        public float Preco { get; set; }
        public DateTime DataHoraDoPedido { get; set; }
    }
}
