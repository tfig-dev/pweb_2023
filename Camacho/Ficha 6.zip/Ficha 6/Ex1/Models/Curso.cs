﻿using System.ComponentModel.DataAnnotations;

namespace Ex1.Models
{
	public class Curso
	{
		public int Id { get; set; }

		[Display(Name = "Nome do curso", Prompt = "Introduza o nome do curso", Description = "Nome do curso")]
		public string Nome { get; set; }
		public bool Disponivel { get; set; }
		public Categoria Categoria { get; set; }

		[Display(Name = "Descrição", Prompt = "Introduza a descrição", Description = "Descrição do curso")]
		public string Descricao { get; set; }

		[Display(Name = "Descrição resumida", Prompt = "Introduza a descrição resumida", Description = "Descrição resumida do curso")]
		public string DescricaoResumida { get; set; }

		[Display(Name = "Requisitos", Prompt = "Introduza os requisitos", Description = "Requisitos para poder frequentar esta formação")]
		public string Requisitos { get; set; }

        [Display(Name = "Idade mínima", Prompt = "Introduza a idade Mínima", Description = "Idade mínima para poder frequentar esta formação")]
		[Range(14, 100, ErrorMessage = "Mínimo: 14 anos, máximo: 100 anos")]
        public int IdadeMinima { get; set; }

		[Display(Name = "Preço", Prompt = "Introduza o preo", Description = "Preço para pagar para poder frequentar esta formação")]
		[Range(150, 1000, ErrorMessage = "Mínimo: 150€, máximo: 1000€")]
		public float Preco { get; set;}
		public bool EmDestaque { get; set; }
    }
}
