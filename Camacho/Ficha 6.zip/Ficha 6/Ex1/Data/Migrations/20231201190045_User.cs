﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Ex1.Migrations
{
    public partial class User : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Agendamento_AspNetUsers_ClienteId1",
                table: "Agendamento");

            migrationBuilder.DropIndex(
                name: "IX_Agendamento_ClienteId1",
                table: "Agendamento");

            migrationBuilder.DropColumn(
                name: "ClienteId1",
                table: "Agendamento");

            migrationBuilder.AlterColumn<string>(
                name: "ClienteId",
                table: "Agendamento",
                type: "nvarchar(450)",
                nullable: false,
                oldClrType: typeof(int),
                oldType: "int");

            migrationBuilder.CreateIndex(
                name: "IX_Agendamento_ClienteId",
                table: "Agendamento",
                column: "ClienteId");

            migrationBuilder.AddForeignKey(
                name: "FK_Agendamento_AspNetUsers_ClienteId",
                table: "Agendamento",
                column: "ClienteId",
                principalTable: "AspNetUsers",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Agendamento_AspNetUsers_ClienteId",
                table: "Agendamento");

            migrationBuilder.DropIndex(
                name: "IX_Agendamento_ClienteId",
                table: "Agendamento");

            migrationBuilder.AlterColumn<int>(
                name: "ClienteId",
                table: "Agendamento",
                type: "int",
                nullable: false,
                oldClrType: typeof(string),
                oldType: "nvarchar(450)");

            migrationBuilder.AddColumn<string>(
                name: "ClienteId1",
                table: "Agendamento",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Agendamento_ClienteId1",
                table: "Agendamento",
                column: "ClienteId1");

            migrationBuilder.AddForeignKey(
                name: "FK_Agendamento_AspNetUsers_ClienteId1",
                table: "Agendamento",
                column: "ClienteId1",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }
    }
}
