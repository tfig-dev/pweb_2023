﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Ex1.Migrations
{
    public partial class Ficha5_v2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropColumn(
                name: "Cliente",
                table: "Agendamento");

            migrationBuilder.AddColumn<int>(
                name: "ClienteId",
                table: "Agendamento",
                type: "int",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "ClienteId1",
                table: "Agendamento",
                type: "nvarchar(450)",
                nullable: true);

            migrationBuilder.CreateIndex(
                name: "IX_Agendamento_ClienteId1",
                table: "Agendamento",
                column: "ClienteId1");

            migrationBuilder.AddForeignKey(
                name: "FK_Agendamento_AspNetUsers_ClienteId1",
                table: "Agendamento",
                column: "ClienteId1",
                principalTable: "AspNetUsers",
                principalColumn: "Id");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Agendamento_AspNetUsers_ClienteId1",
                table: "Agendamento");

            migrationBuilder.DropIndex(
                name: "IX_Agendamento_ClienteId1",
                table: "Agendamento");

            migrationBuilder.DropColumn(
                name: "ClienteId",
                table: "Agendamento");

            migrationBuilder.DropColumn(
                name: "ClienteId1",
                table: "Agendamento");

            migrationBuilder.AddColumn<string>(
                name: "Cliente",
                table: "Agendamento",
                type: "nvarchar(max)",
                nullable: false,
                defaultValue: "");
        }
    }
}
