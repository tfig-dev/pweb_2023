﻿using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace Ex1.Migrations
{
    public partial class NewMigration : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Cursos_Categorias_categoriaId",
                table: "Cursos");

            migrationBuilder.RenameColumn(
                name: "categoriaId",
                table: "Cursos",
                newName: "CategoriaId");

            migrationBuilder.RenameIndex(
                name: "IX_Cursos_categoriaId",
                table: "Cursos",
                newName: "IX_Cursos_CategoriaId");

            migrationBuilder.AddForeignKey(
                name: "FK_Cursos_Categorias_CategoriaId",
                table: "Cursos",
                column: "CategoriaId",
                principalTable: "Categorias",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Cursos_Categorias_CategoriaId",
                table: "Cursos");

            migrationBuilder.RenameColumn(
                name: "CategoriaId",
                table: "Cursos",
                newName: "categoriaId");

            migrationBuilder.RenameIndex(
                name: "IX_Cursos_CategoriaId",
                table: "Cursos",
                newName: "IX_Cursos_categoriaId");

            migrationBuilder.AddForeignKey(
                name: "FK_Cursos_Categorias_categoriaId",
                table: "Cursos",
                column: "categoriaId",
                principalTable: "Categorias",
                principalColumn: "Id",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
