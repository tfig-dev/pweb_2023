﻿using System.Diagnostics;
using Ex1.Data;
using Ex1.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace Ex1.Controllers
{
	public class HomeController : Controller
	{
		private readonly ILogger<HomeController> _logger;
		private readonly ApplicationDbContext _context;

		public HomeController(ILogger<HomeController> logger, ApplicationDbContext context)
		{
			_logger = logger;
			_context = context;
		}

		public async Task<IActionResult> Index()
		{
			IQueryable<Curso> cursos = _context.Cursos;

			cursos = cursos.Where(c => c.Disponivel == true && c.EmDestaque == true);

			return View(await cursos.ToListAsync());
		}

		public IActionResult Privacy()
		{
			return View();
		}

		public IActionResult QuemSomos(){
			return View();
		}

		public IActionResult Cursos()
		{
			return View();
		}

		public IActionResult Contactos()
		{
			return View();
		}

		[ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
		public IActionResult Error()
		{
			return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
		}
	}
}