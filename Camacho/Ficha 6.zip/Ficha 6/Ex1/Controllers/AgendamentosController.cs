﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Ex1.Data;
using Ex1.Models;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using System.Security.Claims;

namespace Ex1.Controllers
{
    public class AgendamentosController : Controller
    {
        private readonly ApplicationDbContext _context;

        public AgendamentosController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Agendamentos
        [Authorize]
        public async Task<IActionResult> Index()
        {
            IQueryable<Agendamento> agendamentos = _context.Agendamentos;
            agendamentos = agendamentos.Include(a => a.Cliente);

            return View(await agendamentos.ToListAsync());
        }

        // GET: Agendamentos/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Agendamentos == null)
            {
                return NotFound();
            }

            var agendamento = await _context.Agendamentos
                .FirstOrDefaultAsync(m => m.Id == id);
            if (agendamento == null)
            {
                return NotFound();
            }

            return View(agendamento);
        }

        // GET: Agendamentos/Create
        [Authorize(Roles = "Cliente")]
        public IActionResult Create()
        {
            if (!User.Identity.IsAuthenticated)
            {
                TempData["ErrorMessage"] = "Só utilizadores autenticados é que podem efetuar agendamentos. Por favor, autentique-se.";
                return RedirectToAction("Login", "Conta");
            }

            return View();
        }

        // POST: Agendamentos/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Cliente")]
        public async Task<IActionResult> Create([Bind("DataInicio,DataFim")] Agendamento agendamento)
        {
            ModelState.Remove(nameof(agendamento.ClienteId));
            ModelState.Remove(nameof(agendamento.Cliente));

            if (ModelState.IsValid)
            {
                agendamento.ClienteId = _context.Users.Where(u => u.UserName == User.Identity.Name).FirstOrDefault().Id;

                TimeSpan duration = agendamento.DataFim - agendamento.DataInicio;
                agendamento.DuracaoEmHoras = duration.Hours;
                agendamento.DuracaoEmMinutos = duration.Minutes;

                agendamento.Preco = CalcularPreco(agendamento.DuracaoEmHoras);

                agendamento.DataHoraDoPedido = DateTime.Now;

                _context.Add(agendamento);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(agendamento);
        }

        // GET: Agendamentos/Edit/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Agendamentos == null)
            {
                return NotFound();
            }

            var agendamento = await _context.Agendamentos.FindAsync(id);
            if (agendamento == null)
            {
                return NotFound();
            }
            return View(agendamento);
        }

        // POST: Agendamentos/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Cliente,DataInicio,DataFim,DuracaoEmHoras,DuracaoEmMinutos,Preco,DataHoraDoPedido")] Agendamento agendamento)
        {
            if (id != agendamento.Id)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(agendamento);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!AgendamentoExists(agendamento.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(agendamento);
        }

        // GET: Agendamentos/Delete/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Agendamentos == null)
            {
                return NotFound();
            }

            var agendamento = await _context.Agendamentos
                .FirstOrDefaultAsync(m => m.Id == id);
            if (agendamento == null)
            {
                return NotFound();
            }

            return View(agendamento);
        }

        // POST: Agendamentos/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Agendamentos == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Agendamento'  is null.");
            }
            var agendamento = await _context.Agendamentos.FindAsync(id);
            if (agendamento != null)
            {
                _context.Agendamentos.Remove(agendamento);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool AgendamentoExists(int id)
        {
          return (_context.Agendamentos?.Any(e => e.Id == id)).GetValueOrDefault();
        }

        private float CalcularPreco(int duracaoEmHoras)
        {
            float preco = 0;
            if (duracaoEmHoras <= 1)
            {
                preco = 100;
            }
            else if (duracaoEmHoras <= 4)
            {
                preco = 200;
            }
            else if (duracaoEmHoras <= 8)
            {
                preco = 300;
            }
            else if (duracaoEmHoras <= 12)
            {
                preco = 400;
            }
            else if (duracaoEmHoras <= 24)
            {
                preco = 500;
            }
            else
            {
                preco = 600;
            }
            return preco;
        }

        [Authorize]
        public IActionResult MeusAgendamentos()
        {
            string userId = User.FindFirstValue(ClaimTypes.NameIdentifier);

            var meusAgendamentos = _context.Agendamentos.Where(a => a.ClienteId == userId).ToList();

            return View(meusAgendamentos);
        }

    }
}
