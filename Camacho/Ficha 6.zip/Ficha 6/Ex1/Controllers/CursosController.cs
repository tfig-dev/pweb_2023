﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using Ex1.Data;
using Ex1.Models;
using Ex1.ViewModels;
using Microsoft.AspNetCore.Authorization;

namespace Ex1.Controllers
{
    public class CursosController : Controller
    {
        private readonly ApplicationDbContext _context;

        public CursosController(ApplicationDbContext context)
        {
            _context = context;
        }

        // GET: Cursos
        public async Task<IActionResult> Index(bool? available)
        {
            IQueryable<Curso> cursos = _context.Cursos;

            if (available.HasValue)
            {
                cursos = cursos.Where(c => c.Disponivel == available.Value);
                ViewData["Title"] = available.Value ? "Cursos Disponíveis" : "Cursos Indisponíveis";
            }

             else
                ViewData["Title"] = "Cursos";

            cursos = cursos.Include(c => c.Categoria);

            return View(await cursos.ToListAsync());
        }

        // POST: Cursos
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Index(string searchTerm)
        {
            IQueryable<Curso> cursos = _context.Cursos;

            if(!string.IsNullOrEmpty(searchTerm))
                cursos = cursos.Where(c => c.Nome.Contains(searchTerm));
            

            ViewData["Title"] = "Cursos (" + searchTerm + ")";

            cursos = cursos.Include(c => c.Categoria);

            return View(await cursos.ToListAsync());
        }

        // GET: Cursos/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Cursos == null)
            {
                return NotFound();
            }

            var curso = await _context.Cursos
                .Include(c => c.Categoria)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (curso == null)
            {
                return NotFound();
            }

            return View(curso);
        }

        // GET: Cursos/Create
        [Authorize(Roles = "Admin")]
        public IActionResult Create()
        {
            return View();
        }

        // POST: Cursos/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Create([Bind("Id,Nome,Disponivel,Categoria,Descricao,DescricaoResumida,Requisitos,IdadeMinima,Preco")] Curso curso)
        {
            ModelState.Remove(nameof(curso.Categoria));


            if (ModelState.IsValid)
            {
                _context.Add(curso);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            return View(curso);
        }

        // GET: Cursos/Edit/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Cursos == null)
            {
                return NotFound();
            }

            var curso = await _context.Cursos.FindAsync(id);
            if (curso == null)
            {
                return NotFound();
            }
            return View(curso);
        }

        // POST: Cursos/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Edit(int id, [Bind("Id,Nome,Disponivel,Categoria,Descricao,DescricaoResumida,Requisitos,IdadeMinima,Preco,EmDesctaque")] Curso curso)
        {
            if (id != curso.Id)
            {
                return NotFound();
            }

            ModelState.Remove(nameof(curso.Categoria));

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(curso);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!CursoExists(curso.Id))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            return View(curso);
        }

        // GET: Cursos/Delete/5
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Cursos == null)
            {
                return NotFound();
            }

            var curso = await _context.Cursos
                .Include(c => c.Categoria)
                .FirstOrDefaultAsync(m => m.Id == id);
            if (curso == null)
            {
                return NotFound();
            }

            return View(curso);
        }

        // POST: Cursos/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        [Authorize(Roles = "Admin")]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Cursos == null)
            {
                return Problem("Entity set 'ApplicationDbContext.Cursos'  is null.");
            }
            var curso = await _context.Cursos.FindAsync(id);
            if (curso != null)
            {
                _context.Cursos.Remove(curso);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        private bool CursoExists(int id)
        {
          return (_context.Cursos?.Any(e => e.Id == id)).GetValueOrDefault();
        }

        public IActionResult IndexSearch()
        {
            return View("Search");
        }

        // GET: Cursos/Search
        public async Task<IActionResult> Search(string searchInput)
        {
            PesquisaCursoViewModel pesquisaCurso = new PesquisaCursoViewModel();

            if (string.IsNullOrEmpty(searchInput))
            {
                pesquisaCurso.ListaDeCursos = await _context.Cursos.Include(c => c.Categoria).ToListAsync();
                ViewData["Title"] = "Cursos";
            }
            else
            {
                pesquisaCurso.ListaDeCursos = await _context.Cursos.Where(c => c.Nome.Contains(searchInput) || c.Descricao.Contains(searchInput) || c.Categoria.Nome.Contains(searchInput)).Include(c => c.Categoria).ToListAsync();
                pesquisaCurso.NumResultados = pesquisaCurso.ListaDeCursos.Count();
                pesquisaCurso.TextoAPesquisar = searchInput;
                ViewData["Title"] = "Cursos (" + pesquisaCurso.TextoAPesquisar + ")";

                foreach (var curso in pesquisaCurso.ListaDeCursos)
                {
                    curso.Nome = curso.Nome.Replace(pesquisaCurso.TextoAPesquisar, "<span class='bg-warning'>" + pesquisaCurso.TextoAPesquisar + "</span>");
                    curso.Descricao = curso.Descricao.Replace(pesquisaCurso.TextoAPesquisar, "<span class='bg-warning'>" + pesquisaCurso.TextoAPesquisar + "</span>");
                }
            }

            return View(pesquisaCurso);
        }

        // POST: Cursos/Search
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Search([Bind("TextoAPesquisar")] PesquisaCursoViewModel pesquisaCurso)
        {
            if (string.IsNullOrEmpty(pesquisaCurso.TextoAPesquisar))
            {
                pesquisaCurso.ListaDeCursos = await _context.Cursos.Include(c => c.Categoria).ToListAsync();
                ViewData["Title"] = "Cursos";
            }
            else
            {
                pesquisaCurso.ListaDeCursos = await _context.Cursos.Where(c => c.Nome.ToUpper().Contains(pesquisaCurso.TextoAPesquisar.ToUpper()) || c.Descricao.ToUpper().Contains(pesquisaCurso.TextoAPesquisar.ToUpper()) || c.Categoria.Nome.ToUpper().Contains(pesquisaCurso.TextoAPesquisar.ToUpper())).Include(c => c.Categoria).ToListAsync();
                pesquisaCurso.NumResultados = pesquisaCurso.ListaDeCursos.Count();
                pesquisaCurso.TextoAPesquisar = pesquisaCurso.TextoAPesquisar;
                ViewData["Title"] = "Cursos (" + pesquisaCurso.TextoAPesquisar + ")";

                foreach (var curso in pesquisaCurso.ListaDeCursos)
                {
                    curso.Nome = curso.Nome.Replace(pesquisaCurso.TextoAPesquisar, "<span class='bg-warning'>" + pesquisaCurso.TextoAPesquisar + "</span>");
                    curso.Descricao = curso.Descricao.Replace(pesquisaCurso.TextoAPesquisar, "<span class='bg-warning'>" + pesquisaCurso.TextoAPesquisar + "</span>");
                }
            }

            return View(pesquisaCurso);
        }

    }
}
