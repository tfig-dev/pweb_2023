## new Cldr( locale )

Create a new instance of Cldr.

| Parameter | Type | Example |
| --- | --- | --- |
| *locale* | String | `"en"`, `"pt-BR"` |

More information in the [specification](http://www.unicode.org/reports/tr35/#Locale).
