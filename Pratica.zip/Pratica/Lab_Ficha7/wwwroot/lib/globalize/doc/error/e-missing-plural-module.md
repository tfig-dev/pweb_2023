## E_MISSING_PLURAL_MODULE

Thrown when plural module is needed, but not loaded, eg. formatting currencies using plural messages.

Error object:

| Attribute | Value |
| --- | --- |
| code | `E_MISSING_PLURAL_MODULE` |
