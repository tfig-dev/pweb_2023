## E_MISSING_CLDR

Thrown when any required CLDR item is NOT found.

Error object:

| Attribute | Value |
| --- | --- |
| code | `E_MISSING_CLDR` |
| path | Missing CLDR item path |

