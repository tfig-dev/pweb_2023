﻿using System.ComponentModel.DataAnnotations;

namespace AutoWEB.Models
{
    public class TipoDeAula
    {
        public int Id { get; set; }

        [Display(Name = "Tipo de Aula", Prompt = "Indique o Tipo de Aula!")]
        [Required(ErrorMessage = "Indique o tipo de aula!")]
        public string Nome { get; set; }

        [Display(Name = "Custo Hora", Prompt = "Custo da Aula!")]
        [DisplayFormat(DataFormatString = "{0:C2}")]

        [Required(ErrorMessage = "Indique o valor hora!")]
        public decimal? ValorHora { get; set; }
    }
}
