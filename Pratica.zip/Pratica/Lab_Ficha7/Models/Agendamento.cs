﻿using System.ComponentModel.DataAnnotations;

namespace AutoWEB.Models
{
    public class Agendamento
    {
        public int Id { get; set; }

        [Display(Name = "Data de Início", Prompt = "Introduza a Data de Início da Aula!")]
        public DateTime? DataInicio { get; set; }
        [Display(Name = "Data de Fim", Prompt = "Introduza a Data de Fim da Aula!")]
        [Required(ErrorMessage = "Indique a data de Início!")]
        public DateTime? DataFim { get; set; }
        [Display(Name = "Duração Horas", Prompt = "Introduza a Duração em Horas!")]
        public double DuracaoHoras { get; set; }

        [Display(Name = "Duração Minutos", Prompt = "Introduza a Duração em Minutos!")]
        public double DuracaoMinutos { get; set; }
        [Display(Name = "Preço", Prompt = "Introduza o Preço Hora!")]
        [DisplayFormat(DataFormatString = "{0:C2}")]
        public decimal? Preco { get; set; }

        public DateTime DataHoraDoPedido { get; set; }

        [Display(Name = "Tipo de Aula", Prompt = "Indique o Tipo de Aula!")]
        public int TipoDeAulaId { get; set; }

        [Display(Name = "Tipo de Aula", Prompt = "Indique o Tipo de Aula!")]
        public TipoDeAula tipoDeAula { get; set; }

        // relacionamento com a entidade ApplicationUser
        public string ApplicationUserId { get; set; }

        [Display(Name = "Utilizador")]
        public ApplicationUser ApplicationUser { get; set; }

    }
}
