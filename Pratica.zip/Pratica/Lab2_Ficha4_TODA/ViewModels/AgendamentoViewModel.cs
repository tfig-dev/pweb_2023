﻿using AutoWEB.Models;
using System.ComponentModel.DataAnnotations;

namespace AutoWEB.ViewModels
{
    public class AgendamentoViewModel
    {
        [Display(Name = "Nome do Cliente", Prompt = "Introduza o nome do cliente")]
        [Required(ErrorMessage = "Indique o nome do cliente!")]
        public string Cliente { get; set; }

        [Display(Name = "Data de Início", Prompt = "yyyy-mm-dd")]
        [Required(ErrorMessage = "Indique a Data de Início!")]
        public DateTime? DataInicio { get; set; }

        [Display(Name = "Data de Fim", Prompt = "yyyy-mm-dd")]
        [Required(ErrorMessage = "Indique a Data de Fim!")]
        public DateTime? DataFim { get; set; }

        [Display(Name = "Tipo de Aula", Prompt = "Escolha o tipo de aula que pretende")]
        public int TipoDeAulaId { get; set; }                
    }
}
