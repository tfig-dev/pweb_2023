﻿using System.ComponentModel.DataAnnotations;

namespace AutoWEB.Models
{
    public class Curso
    {
        public int Id { get; set; }

        [Display(Name = "Nome", Prompt = "Introduza o Nome do curso!")]
        [Required(ErrorMessage = "Indique o nome do curso!")]
        public string Nome { get; set; }

        [Display(Name = "Descrição", Prompt = "Introduza a Descrição do curso!")]
        [Required(ErrorMessage = "Descreva o curso!")]
        public string Descricao { get; set; }

        [Display(Name = "Descrição Resumida", Prompt = "Introduza a Descrição Resumida do curso!")]
        [Required(ErrorMessage = "Descreva resumidamente o curso!")]
        public string DescricaoResumida { get; set; }

        [Display(Name = "Requisitos", Prompt = "Introduza os Requisitos do curso!")]
        [Required(ErrorMessage = "Indique os requisitos do curso!")]
        public string Requisitos { get; set; }

        [Display(Name = "Idade mínima", Prompt = "Idade Mínima",
    Description = "Idade mínima para poder frequentar esta formação")]
        [Required(ErrorMessage = "Indique a Idade Mínima para este curso!")]
        [Range(14, 100, ErrorMessage = "Mínimo: 14 anos, Máximo: 100 anos")]
        public int IdadeMinima { get; set; }

        [Display(Name = "Curso activo?")]
        public bool Disponivel { get; set; }

        [Display(Name = "Curso em Destaque?")]
        public bool EmDestaque { get; set; }

        [Display(Name = "Preço", Prompt = "Preço do curso!")]
        [Required(ErrorMessage = "Indique o Preço do curso!")]
        public decimal? Preco { get; set; }

        [Display(Name = "Categoria")]
        public int? CategoriaId { get; set; }
        public Categoria categoria { get; set; }
    }

}
